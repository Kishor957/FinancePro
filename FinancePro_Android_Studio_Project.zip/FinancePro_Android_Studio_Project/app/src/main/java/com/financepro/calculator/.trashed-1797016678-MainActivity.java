package com.financepro.calculator;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    EditText bike, dp, top, rate, pf, doc, stamp, tenure;
    TextView loanValue, emiValue, breakdown, totalValue;
    LinearLayout root;
    NumberFormat nf = NumberFormat.getIntegerInstance(new Locale("en", "IN"));
    double basic, processing, principal, interest, total, emi;
    String currency(double x) { return "₹" + nf.format(Math.round(x)); }
    double val(EditText e) {
        try { return Double.parseDouble(e.getText().toString().replace(",", "").trim()); }
        catch (Exception ex) { return 0; }
    }
    int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        nf.setGroupingUsed(true);
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        root.setBackgroundColor(Color.rgb(246,248,247));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("FINANCE PRO", 26, "#102A22", true);
        root.addView(title);
        root.addView(text("TWO-WHEELER LOAN CALCULATOR", 12, "#60716A", true));
        space(18);
        section("CUSTOMER & VEHICLE");
        bike = field("Bike amount (₹)", "101000", false);
        dp = field("Customer down payment (₹)", "35000", false);
        section("FINANCE CHARGES");
        top = field("Top / showroom amount (₹)", "0", false);
        rate = field("Flat interest rate (% p.a.)", "12.5", true);
        pf = field("Processing fee (%)", "2.5", true);
        doc = field("Documentation charges (₹)", "500", false);
        stamp = field("Stamp charges (₹)", "300", false);
        tenure = field("Tenure (months)", "18", true);

        section("CUSTOMER QUOTATION");
        loanValue = resultCard("FINAL LOAN AMOUNT", "₹66,000");
        emiValue = resultCard("MONTHLY EMI", "₹0");
        totalValue = resultCard("CUSTOMER TOTAL OUTFLOW (DP + ALL EMIs)", "₹0");
        breakdown = text("", 14, "#24332D", false);
        breakdown.setPadding(dp(14),dp(12),dp(14),dp(12));
        breakdown.setBackground(round("#FFFFFF", 12));
        root.addView(breakdown, params(-1, -2, 0, 8, 0, 8));

        Button copy = button("COPY CUSTOMER QUOTATION");
        root.addView(copy, params(-1, dp(50), 0, 8, 0, 0));
        copy.setOnClickListener(v -> {
            String quote = quotation();
            ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Finance Pro quotation", quote));
            Toast.makeText(this, "Quotation copied", Toast.LENGTH_SHORT).show();
        });
        Button reset = button("RESET");
        root.addView(reset, params(-1, dp(48), 0, 8, 0, 0));
        reset.setOnClickListener(v -> {
            bike.setText("101000"); dp.setText("35000"); top.setText("0");
            rate.setText("12.5"); pf.setText("2.5"); doc.setText("500");
            stamp.setText("300"); tenure.setText("18");
        });
        root.addView(text("Assumption: processing fee is calculated on basic finance. Top and listed charges are added to the financed principal. Flat interest is annual. Actual lender rules may differ.", 11, "#687871", false),
                params(-1,-2,0,16,0,0));
        calculate();
    }

    TextView text(String s, int size, String color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.parseColor(color));
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    void section(String s) {
        space(18);
        root.addView(text(s, 13, "#146C43", true));
        space(8);
    }
    void space(int h) { View v = new View(this); root.addView(v, new LinearLayout.LayoutParams(1, dp(h))); }
    GradientDrawable round(String color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(Color.parseColor(color)); d.setCornerRadius(dp(radius)); return d;
    }
    LinearLayout.LayoutParams params(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h));
        p.setMargins(dp(l),dp(t),dp(r),dp(b)); return p;
    }
    EditText field(String label, String initial, boolean decimal) {
        root.addView(text(label, 12, "#52635B", true), params(-1,-2,0,8,0,4));
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setTextSize(17); e.setTextColor(Color.rgb(25,40,33));
        e.setPadding(dp(12),0,dp(12),0); e.setBackground(round("#FFFFFF",10));
        e.setInputType(decimal ? 8194 : 2);
        e.setText(initial);
        root.addView(e, params(-1,dp(50),0,0,0,2));
        e.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a) {}
            public void onTextChanged(CharSequence s,int st,int before,int count) { calculate(); }
            public void afterTextChanged(Editable ed) {}
        });
        return e;
    }
    TextView resultCard(String label, String value) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14),dp(12),dp(14),dp(12)); card.setBackground(round("#E7F2EB",12));
        card.addView(text(label,11,"#52635B",true));
        TextView val = text(value,25,"#146C43",true);
        card.addView(val);
        root.addView(card, params(-1,-2,0,6,0,4));
        return val;
    }
    Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextSize(13); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setBackground(round("#146C43",12)); return b;
    }
    void calculate() {
        if (bike == null || dp == null || loanValue == null) return;
        double price=val(bike), down=val(dp), months=val(tenure);
        if (price <= 0 || down > price || months <= 0) {
            loanValue.setText("Check inputs"); emiValue.setText("—"); totalValue.setText("—");
            breakdown.setText("Down payment cannot exceed bike amount. Tenure must be greater than zero.");
            return;
        }
        basic = Math.max(0, price-down);
        processing = basic*val(pf)/100.0;
        principal = basic+val(top)+processing+val(doc)+val(stamp);
        interest = principal*val(rate)/100.0*months/12.0;
        total = principal+interest;
        emi = total/months;
        loanValue.setText(currency(principal));
        emiValue.setText(currency(emi));
        totalValue.setText(currency(down+total));
        breakdown.setText(
            "Bike amount                         "+currency(price)+"\n"+
            "Customer down payment       "+currency(down)+"\n"+
            "Basic finance                         "+currency(basic)+"\n"+
            "Top / showroom amount       "+currency(val(top))+"\n"+
            "Processing fee                       "+currency(processing)+"\n"+
            "Documentation                      "+currency(val(doc))+"\n"+
            "Stamp charges                       "+currency(val(stamp))+"\n"+
            "--------------------------------\n"+
            "FINAL LOAN                            "+currency(principal)+"\n"+
            "Flat interest                           "+currency(interest)+"\n"+
            "Total repayment                    "+currency(total)+"\n"+
            "Monthly EMI                          "+currency(emi)+"\n"+
            "Tenure                                    "+nf.format((long)months)+" months"
        );
    }
    String quotation() {
        return "FINANCE PRO - CUSTOMER QUOTATION\n"+breakdown.getText()+
            "\nCustomer total outflow (DP + EMIs): "+currency(val(dp)+total);
    }
}
